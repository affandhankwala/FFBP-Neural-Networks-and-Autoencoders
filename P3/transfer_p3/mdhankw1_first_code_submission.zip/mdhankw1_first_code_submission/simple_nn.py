from calculations import get_mse, multiply_list_by_val, subtract_lists
import numpy as np
from typing import Dict, List


def calculate_z(input_values: List, weights: List, bias: float) -> float:
    # Return the dot product of input values and weights plus the bias term
    return np.dot(input_values, weights) + bias

def calculate_weight_gradient(input_values: List, gradient: float) -> List:
    # Calculate the weight gradients for new weights
    weight_gradients = []
    for value in range(len(input_values)):
        # dL_dwi = dL_dy * xi
        weight_gradients.append(gradient * input_values[value])
    return weight_gradients


def calculate_bias_gradient(value_count: float, predicted: float, expected: float) -> float:
    return 2 / value_count * (predicted - expected)

def build_classifiction_nn(dataset: Dict):
    # Implement logistic regression 

    return

def build_regression_nn(dataset: Dict, eta: float):
    # Implement linear regression without hidden layer
    # Count number of features and number of values per feature
    feature_count = len(dataset['features'])
    feature_length = len(dataset['features'][0].get_data())
    # Initialize weights and bias
    weights = []
    bias = None
    for value_iterator in range(feature_length):
        # Forward propagation
        # Extract feature values of current input feature
        input_values = []
        for feature_iterator in range(feature_count):
            feature_type = dataset['features'][feature_iterator].get_type()
            # Only take nominal, discrete, and continuous values
            if (feature_type == 'nominal' or 
                feature_type == 'continous' or
                feature_type == 'discrete'):
                input_values.append(dataset['features'][feature_iterator].get_data()[value_iterator])
        # Set weights and bias if they are not done so
        if len(weights) == 0:
            weights = [1 for i in range(len(input_values))]
            bias = 1
        predicted = calculate_z(input_values, weights, bias)
        expected = dataset['label'].get_data()[value_iterator]
        # Calculate loss function as derivative of MSE
        gradient = predicted - expected
        # Calculate weight gradients
        weight_gradients = calculate_weight_gradient(input_values, gradient)
        # Calculate new weights
        for w in range(len(weights)):
            weights[w] -= eta * weight_gradients[w]
        # Calculate new bias
        # Bias gradient = gradient
        bias -= eta * gradient

        # # Calculate Loss via MSE
        # expected = dataset['label'].get_data()[value_iterator]
        # # Calculate the loss
        # loss = get_mse(expected, predicted)
        # # Calculate the gradients
        # gradient_weights = calculate_weight_gradient(input_values, feature_length, predicted, expected)
        # gradient_bias = calculate_bias_gradient(feature_length, predicted, expected)
        # # Update values
        # subtracting_list = multiply_list_by_val(gradient_weights, eta)
        # weights = subtract_lists(weights, subtracting_list)
        # bias -= eta * gradient_bias
        print(f"{value_iterator} | Gradient: {gradient}")

    return

def build_simple_nn (dataset: Dict, eta: float):
    # Determine how many input nodes
    # Number of inputs = number of features
    input_count = len(dataset['features'])
    # Determine which type of nn will be constructed
    class_label_type = dataset['label'].get_type()
    if class_label_type == 'nominal':
        # Classifiction problem
        build_classifiction_nn(dataset)
    else:
        # Regression problem
        build_regression_nn(dataset, eta)
